// Empty JS for your own code to be here
function allowDrop(ev) {
    ev.preventDefault();
}

function drag(ev) {
    ev.dataTransfer.setData("text", ev.target.id);
}

function drop(ev) {
    ev.preventDefault();
	
    var data = ev.dataTransfer.getData("text");
    ev.target.appendChild(document.getElementById(data));
	/* console.log(data);
	console.log($("#"+data).html());*/
	var sampleData=[];
	if($("#"+data).html())
	{
	sampleData.push({"key":$("#"+data+" .key").html(),"value":$("#"+data+" .value").html()})
	}
	console.log(sampleData);

}


$(document).on("click","#button",function(){
 	$.ajax({
        type: "GET",
		dataType: "json",
        url: "value.js",
        success: function(result) {
			
			for(i=0;i<result.items.length;i++)
			{
				$('<li class="list-item" id="drag'+i+'"draggable="true" ondragstart="drag(event)"/>').html("<span class='key'>Key = "+result.items[i].key+"</span> <span class='value'> Value = "+result.items[i].value+"</span>").appendTo('ul.list-unstyled');
				$('<option value='+result.items[i].key+'>'+result.items[i].value+'</option>').appendTo('#abc');
			
			}
        },
        error: function(result) {
            alert('error');
        }
    });
}); 

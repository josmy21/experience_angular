$(document).ready(function(){
	$('.main-container').load('loading.html .insurance');
$.ajax({
	type:'GET',
	dataType:'json',
	url:'https://reqres.in/api/users?page=2',
	success: function(result){
     console.log(result.data);
     $.each(result.data,function(key,val){
     	$("#color").append('<option id='+val.id+'">'+val.id+'</option>');
     	$("#state").append('<option id='+val.first_name+'">'+val.first_name+'</option>');
     	$("#city").append('<option id='+val.last_name+'">'+val.last_name+'</option>');
     })
     
	}
	
})


});

$(document).on('change','#checkme',function(){
	console.log($(this));
if($(this).is(':checked')){
	alert("gss")
	$('.load-first').css ('visibility', 'visible');
}
else{
		$('.load-first').css('visibility','hidden');
}
});
$(document).on('click','#submit',function(){
	var color=localStorage.getItem('color');
	var s=localStorage.getItem('state');
	var c=localStorage.getItem('city');
	var f=localStorage.getItem('first');
	var m=localStorage.getItem('middle');
	var l=localStorage.getItem('last');
	sample.color=color;
sample.state=s;
sample.city=c;
	sample.firstname=f;
sample.mname=m;
sample.lname=l;

$.ajax({
	type:'POST',
	dataType:'json',
	url:'https://reqres.in/api/users',
	data:sample,
	success: function(result){
		console.log(result);
		$("#myModal").modal('show');
		$(".modal-body").append('<p>'+result.color+'</p><p>'+result.state+'</p>');
	}
})
	});
$(document).on('click','#next',function(){
	$('.load-first').hide();
	$('.load-second').show();
	localStorage.setItem('color',$('#color').val());
	localStorage.setItem('state',$('#state').val());
	localStorage.setItem('city',$('#city').val());
	localStorage.setItem('first',$('#first').val());
	localStorage.setItem('middle',$('#middle').val());
	localStorage.setItem('last',$('#last').val());
	$.ajax({
		type:'GET',
		dataType:'json',
		url:"https://reqres.in/api/users?page=2",
		success: function(result){
			console.log(result.data);
			$.each(result.data,function(key,val){
				$("#dragdfrom").append('<li id='+val.id+' draggable="true" ondragStart="drag(event)"><span class="key">'+val.id+'</span><span class="value">'+val.first_name+'</span></li>')
			})

		}
	})

});
function drag(event){
	event.dataTransfer.setData('text',event.target.id);
}
function allowDrop(event){
event.preventDefault();
event.target.innerHTML='';
};
var sample;
function drop(event){
	$('#dragdfrom li').css('display','block')
	event.preventDefault();
	var data=event.dataTransfer.getData('text');
	event.target.innerHTML=document.getElementById(data).innerHTML;
	$('#dragdfrom #'+data).css('display','none');
	if($('#'+data).html()){
		console.log($('#'+data).html())
	sample={"key":$('#'+ data + ' .key').html(),"val":$('#'+ data + ' .value').html()};
	}

}

// $(document).on('keyup','#first',function(){

// 	const $label = $(this).siblings('span');

//   if ($('#first').val().length<=2 || $('#first').val().length>=10) {
//     // $label.addClass('input-has-value');
//     $(this).append('<span class="error input-has-value">This field is required</span>');
//   } else {
//     $( ".error" ).remove();
//   }
//  //  if($('#first').val().length<=2 || $('#first').val().length>=10){
//  //        $(this).addClass("error");
// 	// }
// 	// else{
// 	// 	$(this).removeClass("error");
// 	// }
// })

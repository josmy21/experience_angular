import React from 'react';
let fruit;
let array=[];
let cart_items=[];

class Fruit extends React.Component{
	show(){
	let key=this;
	console.log(key);
	let clickedFruitName=Object.keys(fruit)[key];
	let clickedfruit=Object.values(fruit)[key].content;
	console.log(clickedfruit);
	$('.fruitdetail').empty();
	let detail=$('<p></p>').text(clickedfruit);
	let img=$('<img/>').attr('src',Object.values(fruit)[key].src);
	let cost=$('<p></p>').text("Cost : Rs."+Object.values(fruit)[key].cost+"/kg");
	let number=$('<input type="number"/ id="count" min="1">')
	let label=$('<span>How much kg do you want?</span>')
	let buy_button=$('<button ></button>').text('Buy').attr('id',key).bind('click',function(){
	
	let kg=$("#count").val();
	if(kg>1){
	Object.values(fruit)[key].count=kg;
	}
	else{
	Object.values(fruit)[key].count=1;
	}
	let count=0;
	let position;
	for(let i=0;i<cart_items.length;i++){
	if(cart_items[i].name==Object.keys(fruit)[key]){
       count++;
       position=i;
       break;
	}
	}
	if(count==0){
	cart_items.push(Object.values(fruit)[key]);
	}
	else{
	cart_items.splice(position,1);
	cart_items.push(Object.values(fruit)[key]);

	}
    console.log(Object.keys(fruit)[key]);
    console.log(cart_items);
  
	});

	$('.fruitdetail').append(img).append(cost).append(label).append(number).append(detail).append(buy_button);


	}
	
    cart(){
    
    if(cart_items.length!=0){
    let total=0;
    $('.showCart').empty();
    $('.content').hide();
    $('.showCart').show();
    let thead=$('<tr ></tr>').append('<th>S.No</th>').append('<th>Image</th>').append('<th>Name</th>').append('<th>Cost/Kg</th>').append('<th>Count</th>').append('<th>Total</th>');
    let tab=$('<table className="items"></table>').append(thead);
    $('.showCart').append(tab);
    for(let i=0; i<cart_items.length;i++){
    let newrow=$('<tr></tr>');
    let no=$('<td></td>').text(i+1);
    let pic=$('<img/>').attr('src',cart_items[i].src);
    let img= $('<td></td>').append(pic)
    let name=$('<td></td>').text(cart_items[i].name);
   let price=$('<td></td>').text(cart_items[i].cost);
   let count=$('<td></td>').text(cart_items[i].count);
   let amnt=$('<td></td>').text((cart_items[i].count)*(cart_items[i].cost));
   newrow.append(no).append(img).append(name).append(price).append(count).append(amnt);
    tab.append(newrow)
    total=((cart_items[i].count)*(cart_items[i].cost))+total;
    }  
    alert(total)
 
     $('.showCart').append('<p>Your total amount is Rs.'+total+'</p>')
    }
    else{
    $('.fruitdetail').empty();
    let emptycart=$('<img/>').attr('src', 'emptycart.jpg')
    $('.fruitdetail').append(emptycart)
    }
    }
    home(){
   $('.content').show();
   $('.showCart').hide();
    }

	render(){
	
	let buy;
	fruit=this.props.child;
	if(fruit!=undefined){
	console.log(Object.values(fruit)[0].content);
	let fruitKey=Object.keys(fruit);
	console.log(fruitKey)
	for(let i=0;i<fruitKey.length;i++){
	let handle=this.show.bind(i);
	 
     array.push(<li key={fruitKey[i]} onClick={handle}>{fruitKey[i]}</li>)
	}
	let initialdetail=Object.values(fruit)[0].content;
	let value=$('<p></p>').text(initialdetail);
	let img=$('<img/>').attr('src',Object.values(fruit)[0].src);
	let cost=$('<p></p>').text("Cost : Rs."+Object.values(fruit)[0].cost+"/kg");
	let label=$('<span>How much kg do you want?</span>')
	let number=$('<input type="number" id="count" min="1"  />')
	let buy_button=$('<button ></button>').text('Buy').attr('id',0).bind('click',function(){
    let kg=$("#count").val();
	if(kg>1){
	Object.values(fruit)[0].count=kg;
	}
	else{
	Object.values(fruit)[0].count=1;
	}
	let count=0;
	let position;
	for(let i=0;i<cart_items.length;i++){
	if(cart_items[i].name==Object.keys(fruit)[key]){
       count++;
       position=i;
       break;
	}
	}
	if(count==0){
	cart_items.push(Object.values(fruit)[key]);
	}
	else{
	cart_items.splice(position,1);
	cart_items.push(Object.values(fruit)[key]);

	}
	});
	$('.fruitdetail').append(img).append(cost).append(label).append(number).append(value).append(buy_button);
	
	}
	
	return(
	<section>
	<button onClick={this.cart}>Cart</button>
	<button onClick={this.home}>Home</button>
	<div className="content">
	<ul className="fruitlist">
	{array}
	</ul>

	<div className="fruitdetail"></div>
	</div>
	<div className="showCart"></div>
	</section>
	);
	}
}
export default Fruit;
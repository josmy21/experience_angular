import React from 'react';
import ReactDom from 'react-dom';
import App from './component/app.jsx';
import Fruit from './component/fruit.jsx';
import Header from './component/fruithead.jsx';

 ReactDom.render(<App/>,document.getElementById('container'));
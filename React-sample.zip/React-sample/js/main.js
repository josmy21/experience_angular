import React from 'react';
import ReactDom from 'react-dom';
import App from './component/app.jsx';
import Head from './component/header.jsx';
import Foot from './component/footer.jsx';


ReactDom.render(<App/>,document.getElementById('container'));
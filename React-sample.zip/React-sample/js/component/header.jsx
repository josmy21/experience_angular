import React from 'react';
class Head extends React.Component{
	render(){
	return(
	<div className="header">
	<p>This is header</p>
	</div>

	)
	}
}
export default Head;
import React from 'react';
class Foot extends React.Component{
	render(){
	return(
	<div className="footer">
	<p>This is footer</p>
	</div>
	);
	}
}
export default Foot;